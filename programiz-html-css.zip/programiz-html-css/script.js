// Set year in footer
document.getElementById('year').textContent = new Date().getFullYear();

// Simple contact form handler
const form = document.getElementById('contactForm');
form.addEventListener('submit', function (e) {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const phone = document.getElementById('phone').value.trim();

  // Basic validation
  if (!name || !email || !phone) {
    alert('Please fill all contact fields.');
    return;
  }

  // For CodePen demo we'll just show a message.
  alert('Message sent!\\n\\nName: ' + name + '\\nEmail: ' + email + '\\nPhone: ' + phone);

  // reset form if desired:
  // form.reset();
});
